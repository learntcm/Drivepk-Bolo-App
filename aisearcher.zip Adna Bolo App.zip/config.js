// Configuration file for OpenAI API
// Edit this file directly with your API key

window.__APP_CONFIG__ = {
  openAIKey: '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',
  // customBackendUrl: 'https://your-backend.com/api/endpoint', // Optional: for custom backend
  apiBaseUrl: '/' // Relative path for proxy
};
